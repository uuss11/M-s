
import React from 'react';
import './App.css';

function App() {
  return (
    <div style={{ 
      display: 'flex', 
      justifyContent: 'center', 
      alignItems: 'center', 
      minHeight: '100vh',
      backgroundColor: '#0a0014',
      color: '#f0f0f0',
      fontFamily: "'Tajawal', 'Cairo', sans-serif"
    }}>
      <div style={{ textAlign: 'center', padding: '2rem' }}>
        <h1 style={{ 
          fontSize: '2.5rem', 
          marginBottom: '1rem',
          background: 'linear-gradient(to right, #d8bfd8, #f0f0f0)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent'
        }}>
          مصطفى | 𝑴𝒖𝒔𝒕𝒂𝒇𝒂 🔮
        </h1>
        <p style={{ fontSize: '1.2rem', color: '#d8bfd8', marginBottom: '2rem' }}>
          مصمم فيديوهات احترافية | مصمم افتارات مميزة
        </p>
        <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center' }}>
          <a href="https://t.me/Q911O" target="_blank" rel="noopener noreferrer" style={{
            padding: '12px 24px',
            backgroundColor: '#8a2be2',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '8px',
            fontWeight: 'bold',
            transition: 'all 0.3s ease'
          }}>
            تواصل معي
          </a>
        </div>
      </div>
    </div>
  );
}

export default App;
