
export class GradientAnimation {
  private colors: number[][];
  private step: number;
  private colorIndices: number[];
  private gradientSpeed: number;

  constructor() {
    this.colors = [
      [26, 0, 51], [76, 26, 117], [138, 43, 226], [139, 0, 255]
    ];
    this.step = 0;
    this.colorIndices = [0, 1, 2, 3];
    this.gradientSpeed = 0.002;
  }

  updateGradient(): [string, string] {
    if (this.step >= 1) {
      this.step = 0;
      this.colorIndices[0] = this.colorIndices[1];
      this.colorIndices[2] = this.colorIndices[3];
      this.colorIndices[1] = (this.colorIndices[0] + Math.floor(1 + Math.random() * (this.colors.length - 1))) % this.colors.length;
      this.colorIndices[3] = (this.colorIndices[2] + Math.floor(1 + Math.random() * (this.colors.length - 1))) % this.colors.length;
    }

    this.step += this.gradientSpeed;
    const t = this.step;

    const color1 = this.colors[this.colorIndices[0]];
    const color2 = this.colors[this.colorIndices[1]];
    const color3 = this.colors[this.colorIndices[2]];
    const color4 = this.colors[this.colorIndices[3]];

    const r1 = Math.round(color1[0] * (1 - t) + color2[0] * t);
    const g1 = Math.round(color1[1] * (1 - t) + color2[1] * t);
    const b1 = Math.round(color1[2] * (1 - t) + color2[2] * t);
    const c1 = `rgb(${r1}, ${g1}, ${b1})`;

    const r2 = Math.round(color3[0] * (1 - t) + color4[0] * t);
    const g2 = Math.round(color3[1] * (1 - t) + color4[1] * t);
    const b2 = Math.round(color3[2] * (1 - t) + color4[2] * t);
    const c2 = `rgb(${r2}, ${g2}, ${b2})`;

    return [c1, c2];
  }

  connect(context: CanvasRenderingContext2D): void {
    const [c1, c2] = this.updateGradient();
    const grad = context.createLinearGradient(0, 0, window.innerWidth, window.innerHeight);
    grad.addColorStop(0, c1);
    grad.addColorStop(1, c2);
    context.fillStyle = grad;
    context.fillRect(0, 0, window.innerWidth, window.innerHeight);
  }
}

export const createParticles = (container: HTMLElement, count: number = 30): void => {
  for (let i = 0; i < count; i++) {
    const particle = document.createElement('div');
    particle.classList.add('particle');
    
    const size = Math.random() * 5 + 3;
    particle.style.width = `${size}px`;
    particle.style.height = `${size}px`;
    
    particle.style.left = `${Math.random() * 100}vw`;
    particle.style.top = `${Math.random() * 100}vh`;
    
    particle.style.animationDelay = `${Math.random() * 15}s`;
    
    container.appendChild(particle);
  }
};

export const setupCardInteractions = (card: HTMLElement): void => {
  card.addEventListener('mousemove', (e) => {
    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateX = (y - centerY) / 20;
    const rotateY = (centerX - x) / 20;

    card.style.setProperty('--mouse-x', `${x}px`);
    card.style.setProperty('--mouse-y', `${y}px`);
    card.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
  });

  card.addEventListener('mouseleave', () => {
    card.style.transform = 'rotateX(0deg) rotateY(0deg)';
  });
};
