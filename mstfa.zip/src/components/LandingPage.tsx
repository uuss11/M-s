
import React from 'react';
import './LandingPage.css';

const LandingPage: React.FC = () => {
  return (
    <div className="landing-container">
      <canvas id="gradient-canvas" className="gradient-canvas"></canvas>
      <div className="particles" id="particles"></div>
      
      <main className="vcard-container">
        <section className="vcard">
          <figure className="profile-picture-wrapper">
            <img 
              className="profile-picture" 
              src="https://files.catbox.moe/e1dryd.jpg" 
              alt="صورة شخصية لمصطفى"
            />
          </figure>

          <header className="user-info">
            <h1 className="name">مصطفى | 𝑴𝒖𝒔𝒕𝒂𝒇𝒂 🔮</h1>
            <p className="title">
              <span id="typed-title"></span>
            </p>
          </header>

          <nav className="social-links">
            <a href="https://t.me/Q911O" target="_blank" title="تليجرام">
              <i className="fab fa-telegram"></i>
            </a>
            <a href="https://www.instagram.com/senzo.edit?igsh=MTd6bzE1bTAyYTdsMQ==" target="_blank" title="انستجرام">
              <i className="fab fa-instagram"></i>
            </a>
            <a href="https://www.tiktok.com/@es8n?_t=ZS-8z4oc7pKsbM&_r=1" target="_blank" title="تيك توك">
              <i className="fab fa-tiktok"></i>
            </a>
          </nav>

          <footer className="action-buttons">
            <a className="action-btn primary" href="https://t.me/Q911O" target="_blank">
              <i className="fas fa-user-circle"></i>
              <span>حسابي الشخصي</span>
            </a>
            <a className="action-btn" href="https://t.me/esb8g" target="_blank">
              <i className="fas fa-satellite-dish"></i>
              <span>قناتي على تليجرام</span>
            </a>
          </footer>
          
          <div className="signature">
            جميع الحقوق محفوظة | مصطفى ©2025
          </div>
        </section>
      </main>
    </div>
  );
};

export default LandingPage;
