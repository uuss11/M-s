
import { useEffect, useRef } from 'react';

export const useTypedAnimation = (strings: string[], options: any = {}) => {
  const typedRef = useRef<HTMLSpanElement>(null);
  
  useEffect(() => {
    if (typeof Typed !== 'undefined' && typedRef.current) {
      const typed = new Typed(typedRef.current, {
        strings,
        typeSpeed: 60,
        backSpeed: 30,
        backDelay: 2500,
        startDelay: 1000,
        loop: true,
        smartBackspace: true,
        ...options
      });
      
      return () => {
        typed.destroy();
      };
    }
  }, [strings, options]);
  
  return typedRef;
};
